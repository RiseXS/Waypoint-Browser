const { contextBridge } = require('electron');
const path = require('path');
const { pathToFileURL } = require('url');

contextBridge.exposeInMainWorld('chrome_', {
  homepageURL: pathToFileURL(path.join(__dirname, 'homepage.html')).toString(),
});
