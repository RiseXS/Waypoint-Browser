# Waypoint — a tiny Chromium browser with a homepage you control

An Electron app: a real Chromium browser window (address bar, back/forward,
reload) whose home tab is a homepage you can edit right from the page itself —
no config files to touch.

## Run it

**Windows — one click:** double-click `install.bat` once, then `start.bat`
any time after that to open the browser.

**Manual / any OS:**

```bash
cd custom-browser
npm install
npm start
```

Requires [Node.js](https://nodejs.org). The first `npm install` downloads
Electron (a bundled Chromium + Node runtime), so it needs an internet
connection once.

## Using it

- Type in the address bar to go to a site, or type a search phrase to search.
- The house icon (⌂) always returns to your homepage.
- On the homepage, click the gear icon (top right) to open **Customize**:
  - your name (used in the greeting)
  - the search engine used when you type a phrase instead of a URL
  - an accent color
  - your **Waypoints** — the list of quick links, which you can add to or
    remove from freely
- Settings are saved automatically in the browser's local storage, so they
  persist between launches.

## Files

| File            | Purpose                                              |
|-----------------|-------------------------------------------------------|
| `main.js`       | Electron entry point; creates the browser window      |
| `preload.js`    | Safely exposes the homepage's file path to the chrome  |
| `index.html` / `chrome.css` / `renderer.js` | The toolbar + the `<webview>` that renders actual web pages |
| `homepage.html` / `homepage.css` / `homepage.js` | Your customizable homepage |

## Making it your own further

- Swap the default waypoints or accent color in the `DEFAULTS` object at the
  top of `homepage.js`.
- Change the default search engine by editing `engine` in that same object
  (any URL that expects the query appended to the end works).
- Package it into an installable app later with
  [`electron-builder`](https://www.electron.build/) or
  [`electron-forge`](https://www.electronforge.io/) — not included here to
  keep the project minimal.
