const { app, BrowserWindow, session } = require('electron');
const path = require('path');

function createWindow() {
  const win = new BrowserWindow({
    width: 1320,
    height: 840,
    minWidth: 760,
    minHeight: 480,
    backgroundColor: '#14181f',
    autoHideMenuBar: true, // keep the chrome minimal; press Alt to reveal the menu
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      webviewTag: true, // the actual Chromium page area is a <webview>
    },
  });

  win.loadFile('index.html');
}

app.whenReady().then(() => {
  // Give every <webview> the same permissions a normal browser tab would have.
  session.defaultSession.setPermissionRequestHandler((_wc, _permission, callback) => callback(true));

  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
