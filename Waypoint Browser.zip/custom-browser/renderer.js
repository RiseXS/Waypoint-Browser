const webview = document.getElementById('view');
const addressForm = document.getElementById('address-form');
const addressInput = document.getElementById('address');
const backBtn = document.getElementById('back');
const forwardBtn = document.getElementById('forward');
const reloadBtn = document.getElementById('reload');
const homeBtn = document.getElementById('home');

const HOME_URL = window.chrome_.homepageURL;

webview.addEventListener('dom-ready', () => {
  webview.setZoomLevel(0);
  updateNavState();
});

webview.src = HOME_URL;

function isHome(url) {
  return url === HOME_URL || url.startsWith(HOME_URL);
}

function updateAddressBar(url) {
  addressInput.value = isHome(url) ? '' : url;
}

function updateNavState() {
  backBtn.disabled = !webview.canGoBack();
  forwardBtn.disabled = !webview.canGoForward();
}

webview.addEventListener('did-navigate', (e) => {
  updateAddressBar(e.url);
  updateNavState();
});

webview.addEventListener('did-navigate-in-page', (e) => {
  updateAddressBar(e.url);
  updateNavState();
});

webview.addEventListener('page-title-updated', (e) => {
  document.title = isHome(webview.getURL()) ? 'Waypoint' : e.title;
});

backBtn.addEventListener('click', () => webview.goBack());
forwardBtn.addEventListener('click', () => webview.goForward());
reloadBtn.addEventListener('click', () => webview.reload());
homeBtn.addEventListener('click', () => webview.loadURL(HOME_URL));

addressForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const raw = addressInput.value.trim();
  if (!raw) return;
  webview.loadURL(resolveInput(raw));
  webview.focus();
});

function resolveInput(raw) {
  const looksLikeUrl = /^[a-z]+:\/\//i.test(raw) || /^[\w-]+(\.[\w-]+)+(\/.*)?$/i.test(raw);
  if (looksLikeUrl) {
    return /^[a-z]+:\/\//i.test(raw) ? raw : `https://${raw}`;
  }
  return `https://www.google.com/search?q=${encodeURIComponent(raw)}`;
}
