const STORAGE_KEY = 'waypoint.settings.v1';

// Search engine and accent color are fixed and not user-editable.
const SEARCH_ENGINE = 'https://www.google.com/search?q=';
const ACCENT = '#c99b3d';

const DEFAULTS = {
  links: [
    { label: 'Mail', url: 'https://mail.google.com' },
    { label: 'Calendar', url: 'https://calendar.google.com' },
    { label: 'Notes', url: 'https://notion.so' },
    { label: 'Reading', url: 'https://news.ycombinator.com' },
  ],
};

function loadSettings() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return structuredClone(DEFAULTS);
    const parsed = JSON.parse(raw);
    // Only the links are ever persisted now.
    return { links: Array.isArray(parsed.links) ? parsed.links : structuredClone(DEFAULTS.links) };
  } catch {
    return structuredClone(DEFAULTS);
  }
}

function saveSettings(settings) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
}

let settings = loadSettings();
let draftLinks = [...settings.links];

// ---------- clock + greeting ----------

function tick() {
  const now = new Date();
  document.getElementById('clock').textContent = now.toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
  });

  const hour = now.getHours();
  const time = hour < 5 ? 'night' : hour < 12 ? 'morning' : hour < 18 ? 'afternoon' : 'evening';
  document.getElementById('greeting').textContent = `Good ${time}, traveller.`;
}
tick();
setInterval(tick, 15000);

// ---------- accent ----------

function applyAccent() {
  document.body.style.setProperty('--accent', ACCENT);
}

// ---------- waypoints list ----------

function renderLinks() {
  const list = document.getElementById('link-list');
  list.innerHTML = '';

  if (settings.links.length === 0) {
    const li = document.createElement('li');
    li.className = 'empty-hint';
    li.textContent = 'No waypoints yet — add some from the customize panel.';
    list.appendChild(li);
    return;
  }

  for (const { label, url } of settings.links) {
    const li = document.createElement('li');
    const a = document.createElement('a');
    a.href = url;
    const labelSpan = document.createElement('span');
    labelSpan.className = 'label';
    labelSpan.textContent = label;
    const urlSpan = document.createElement('span');
    urlSpan.className = 'url';
    urlSpan.textContent = url.replace(/^https?:\/\//, '');
    a.append(labelSpan, urlSpan);
    li.appendChild(a);
    list.appendChild(li);
  }
}

// ---------- search ----------

document.getElementById('search-form').addEventListener('submit', (e) => {
  e.preventDefault();
  const raw = document.getElementById('search-input').value.trim();
  if (!raw) return;
  const looksLikeUrl = /^[a-z]+:\/\//i.test(raw) || /^[\w-]+(\.[\w-]+)+(\/.*)?$/i.test(raw);
  const target = looksLikeUrl
    ? (/^[a-z]+:\/\//i.test(raw) ? raw : `https://${raw}`)
    : `${SEARCH_ENGINE}${encodeURIComponent(raw)}`;
  window.location.href = target;
});

// ---------- drawer ----------

const drawer = document.getElementById('drawer');
const scrim = document.getElementById('scrim');

function openDrawer() {
  draftLinks = [...settings.links];
  renderEditList();
  drawer.classList.add('open');
  drawer.setAttribute('aria-hidden', 'false');
  scrim.hidden = false;
}

function closeDrawer() {
  drawer.classList.remove('open');
  drawer.setAttribute('aria-hidden', 'true');
  scrim.hidden = true;
}

document.getElementById('settings-toggle').addEventListener('click', openDrawer);
document.getElementById('drawer-close').addEventListener('click', closeDrawer);
scrim.addEventListener('click', closeDrawer);

function renderEditList() {
  const list = document.getElementById('edit-list');
  list.innerHTML = '';
  draftLinks.forEach((link, i) => {
    const li = document.createElement('li');
    const span = document.createElement('span');
    span.textContent = `${link.label} — ${link.url.replace(/^https?:\/\//, '')}`;
    const btn = document.createElement('button');
    btn.className = 'remove';
    btn.type = 'button';
    btn.textContent = '\u2715';
    btn.addEventListener('click', () => {
      draftLinks.splice(i, 1);
      renderEditList();
    });
    li.append(span, btn);
    list.appendChild(li);
  });
}

document.getElementById('add-link').addEventListener('click', () => {
  const labelInput = document.getElementById('new-label');
  const urlInput = document.getElementById('new-url');
  const label = labelInput.value.trim();
  let url = urlInput.value.trim();
  if (!label || !url) return;
  if (!/^[a-z]+:\/\//i.test(url)) url = `https://${url}`;
  draftLinks.push({ label, url });
  labelInput.value = '';
  urlInput.value = '';
  renderEditList();
});

document.getElementById('save-settings').addEventListener('click', () => {
  settings = { links: [...draftLinks] };
  saveSettings(settings);
  renderLinks();
  closeDrawer();
});

document.getElementById('reset-defaults').addEventListener('click', () => {
  settings = structuredClone(DEFAULTS);
  saveSettings(settings);
  renderLinks();
  closeDrawer();
});

// ---------- init ----------

applyAccent();
renderLinks();
